module.exports = async (ctx) => {
  try {
    const url = 'https://lldev.thespacedevs.com/2.3.0/events/?limit=100&format=json';

    console.log('���ڻ�ȡ�¼�����...');
    console.log(`����URL: ${url}`);

    const result = await ctx.httpclient.request(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      },
      timeout: 30000,
      dataType: 'json'
    });

    if (result.status !== 200) {
      throw new Error(`����ʧ�ܣ�״̬��: ${result.status}`);
    }

    const data = result.data;
    const events = data.results || [];
    console.log(`��ȡ�� ${events.length} ���¼���¼`);

    const updateTime = new Date();
    let newRecordsCount = 0;

    for (const event of events) {
      const { result: queryResult } = await ctx.mpserverless.db.collection('Events').findOne({
        id: event.id.toString()
      });

      const eventData = {
        ...event,
        updatedAt: updateTime
      };

      if (queryResult) {
        await ctx.mpserverless.db.collection('Events').updateOne({
          _id: queryResult._id
        }, {
          $set: eventData
        });
      } else {
        await ctx.mpserverless.db.collection('Events').insertOne(eventData);
        newRecordsCount++;
      }
    }

    const { result: countResult } = await ctx.mpserverless.db.collection('Events').count();

    console.log(`�¼�����ͬ����ɣ����� ${newRecordsCount} ����¼�����ݿ��ܼ�¼��: ${countResult}`);

    return {
      success: true,
      message: '�¼�����ͬ�����',
      data: {
        processedCount: events.length,
        newRecordsCount: newRecordsCount,
        totalRecordsInDatabase: countResult,
        lastSyncTime: updateTime
      }
    };
  } catch (error) {
    console.error('��ȡ�¼�����ʧ��:', error);
    return {
      success: false,
      message: '��ȡ�¼�����ʧ��',
      error: error.message
    };
  }
};