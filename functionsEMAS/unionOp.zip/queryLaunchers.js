module.exports = async (ctx) => {
  try {
    const page = ctx.args.page || 1;
    const size = ctx.args.size || 20;
    const skip = (page - 1) * size;

    const { result: queryResult } = await ctx.mpserverless.db.collection('Launchers')
      .find()
      .orderBy('name', 'asc')
      .skip(skip)
      .limit(size);

    const { result: countResult } = await ctx.mpserverless.db.collection('Launchers').count();

    return {
      success: true,
      data: {
        list: queryResult,
        total: countResult,
        page,
        size
      }
    };
  } catch (error) {
    console.error('��ѯ����������ʧ��:', error);
    return {
      success: false,
      message: '��ѯ����������ʧ��',
      error: error.message
    };
  }
};