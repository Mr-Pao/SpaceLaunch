const https = require('https');

module.exports = async (ctx) => {
  if (ctx.args?.deploy_test === true) {
    return "v1.2"
  }

  const triggerName = ctx.triggerName || 'unknown';
  console.log(`������ ${triggerName} ������`);

  try {
    // ����ִ�У����ٳ�ʱ����
    const results = [];
    
    console.log('Step 1: ͬ�� Launches...');
    results.push(await syncData(ctx, 'Launches', 'https://lldev.thespacedevs.com/2.3.0/launches/?limit=20&format=json'));

    console.log('Step 2: ͬ�� Launchers...');
    results.push(await syncData(ctx, 'Launchers', 'https://lldev.thespacedevs.com/2.3.0/launchers/?limit=20&format=json'));

    console.log('Step 3: ͬ�� Agencies...');
    results.push(await syncData(ctx, 'Agencies', 'https://lldev.thespacedevs.com/2.3.0/agencies/?limit=20&format=json'));

    console.log('Step 4: ͬ�� Events...');
    results.push(await syncData(ctx, 'Events', 'https://lldev.thespacedevs.com/2.3.0/events/?limit=20&format=json'));

    const totalNew = results.reduce((sum, r) => sum + (r.newRecordsCount || 0), 0);
    const totalProcessed = results.reduce((sum, r) => sum + (r.processedCount || 0), 0);

    console.log(`��ʱ������ɣ������� ${totalProcessed} ����¼������ ${totalNew} ��`);

    return {
      success: true,
      message: '��ʱ����ִ�����',
      results: results
    };
  } catch (error) {
    console.error('��ʱ����ִ��ʧ��:', error);
    return {
      success: false,
      message: error.message
    };
  }
};

// ͨ��ͬ������
const syncData = async (ctx, collectionName, apiUrl) => {
  try {
    console.log(`��ʼͬ�� ${collectionName}...`);
    
    const data = await fetchFromApi(apiUrl);
    const items = data.results || [];
    
    if (items.length === 0) {
      return { success: true, message: `${collectionName} û��������`, processedCount: 0, newRecordsCount: 0 };
    }

    const updateTime = new Date();
    let newRecordsCount = 0;

    // ����������ȷ���ȶ�
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      
      const { result: existing } = await ctx.mpserverless.db.collection(collectionName).findOne({
        id: item.id.toString()
      });

      const itemData = {
        ...item,
        updatedAt: updateTime
      };

      if (existing) {
        await ctx.mpserverless.db.collection(collectionName).updateOne({
          _id: existing._id
        }, {
          $set: itemData
        });
      } else {
        await ctx.mpserverless.db.collection(collectionName).insertOne(itemData);
        newRecordsCount++;
      }
    }

    console.log(`${collectionName} ͬ����ɣ����� ${newRecordsCount} ��`);

    return {
      success: true,
      message: `${collectionName} ͬ�����`,
      processedCount: items.length,
      newRecordsCount: newRecordsCount
    };
  } catch (error) {
    console.error(`${collectionName} ͬ��ʧ��:`, error);
    return {
      success: false,
      message: `${collectionName} ͬ��ʧ��: ${error.message}`
    };
  }
};

// ��API��ȡ����
const fetchFromApi = async (url) => {
  return new Promise((resolve, reject) => {
    const options = {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
      timeout: 15000,
      rejectUnauthorized: false
    };

    const req = https.request(new URL(url), options, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(new Error(`JSON����ʧ��: ${e.message}`));
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('����ʱ'));
    });

    req.end();
  });
};